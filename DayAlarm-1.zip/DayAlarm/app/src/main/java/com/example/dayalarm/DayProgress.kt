package com.example.dayalarm

import java.time.Duration
import java.time.ZonedDateTime

object DayProgress {
    /** Share of the chosen window (startMin..endMin, minutes after midnight) that has passed, 0..100 */
    fun percent(startMin: Int, endMin: Int, now: ZonedDateTime = ZonedDateTime.now()): Double {
        val midnight = now.toLocalDate().atStartOfDay(now.zone)
        val start = midnight.plusMinutes(startMin.toLong())
        val end = midnight.plusMinutes(endMin.toLong())
        val total = Duration.between(start, end).toMillis().toDouble()
        if (total <= 0) return 0.0
        val elapsed = Duration.between(start, now).toMillis().toDouble()
        return (elapsed / total * 100.0).coerceIn(0.0, 100.0)
    }
}
