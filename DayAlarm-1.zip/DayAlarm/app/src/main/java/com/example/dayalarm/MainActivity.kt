package com.example.dayalarm

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { DayAlarmScreen() } } }
    }
}

@Composable
fun DayAlarmScreen() {
    val context = LocalContext.current
    var minutesText by remember { mutableStateOf(AlarmScheduler.intervalMinutes(context).toString()) }
    var startMin by remember { mutableStateOf(AlarmScheduler.startMinute(context)) }
    var endMin by remember { mutableStateOf(AlarmScheduler.endMinute(context)) }
    var running by remember { mutableStateOf(AlarmScheduler.isRunning(context)) }
    var nextAt by remember { mutableStateOf(AlarmScheduler.nextTrigger(context)) }
    var now by remember { mutableStateOf(ZonedDateTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now()
            running = AlarmScheduler.isRunning(context)
            nextAt = AlarmScheduler.nextTrigger(context)
            delay(1000)
        }
    }

    val percent = DayProgress.percent(startMin, endMin, now)
    val timeFmt = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Your day so far", style = MaterialTheme.typography.titleMedium)
        Text(
            String.format(Locale.getDefault(), "%.1f%%", percent),
            fontSize = 64.sp,
            fontWeight = FontWeight.Bold
        )
        LinearProgressIndicator(
            progress = { (percent / 100.0).toFloat() },
            modifier = Modifier.fillMaxWidth().height(12.dp)
        )
        Text(now.format(timeFmt), style = MaterialTheme.typography.bodyLarge)

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = minutesText,
            onValueChange = { minutesText = it.filter(Char::isDigit).take(4) },
            label = { Text("Alarm every … minutes") },
            enabled = !running,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 45, 60, 90).forEach { m ->
                FilterChip(
                    selected = minutesText == m.toString(),
                    onClick = { if (!running) minutesText = m.toString() },
                    enabled = !running,
                    label = { Text("$m") }
                )
            }
        }

        fun fmt(m: Int) = String.format(Locale.getDefault(), "%02d:%02d", m / 60, m % 60)
        fun pick(initial: Int, onPicked: (Int) -> Unit) {
            TimePickerDialog(
                context, { _, h, min -> onPicked(h * 60 + min) },
                initial / 60, initial % 60, true
            ).show()
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(
                onClick = { pick(startMin) { startMin = it } },
                enabled = !running,
                modifier = Modifier.weight(1f)
            ) { Text("From " + fmt(startMin)) }
            OutlinedButton(
                onClick = { pick(endMin) { endMin = it } },
                enabled = !running,
                modifier = Modifier.weight(1f)
            ) { Text("Until " + fmt(endMin)) }
        }
        val windowOk = endMin > startMin
        if (!windowOk) {
            Text(
                "\"Until\" must be later than \"From\"",
                color = MaterialTheme.colorScheme.error
            )
        }

        val minutes = minutesText.toIntOrNull() ?: 0
        Button(
            onClick = {
                if (running) {
                    AlarmScheduler.stop(context)
                } else if (minutes >= 1 && windowOk) {
                    AlarmScheduler.start(context, minutes, startMin, endMin)
                }
                running = AlarmScheduler.isRunning(context)
                nextAt = AlarmScheduler.nextTrigger(context)
            },
            enabled = running || (minutes >= 1 && windowOk),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text(if (running) "Stop" else "Start", fontSize = 18.sp)
        }

        if (running && nextAt > 0) {
            Text(
                "Next alarm " + Instant.ofEpochMilli(nextAt)
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT, FormatStyle.SHORT)),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
