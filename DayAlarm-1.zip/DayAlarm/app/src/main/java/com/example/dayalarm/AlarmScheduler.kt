package com.example.dayalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.ZonedDateTime

object AlarmScheduler {
    const val ACTION_TICK = "com.example.dayalarm.TICK"
    const val ACTION_STOP = "com.example.dayalarm.STOP"

    private const val PREFS = "day_alarm_prefs"
    private const val KEY_INTERVAL = "interval_min"
    private const val KEY_START = "start_min"
    private const val KEY_END = "end_min"
    private const val KEY_RUNNING = "running"
    private const val KEY_NEXT = "next_trigger"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun intervalMinutes(c: Context): Int = prefs(c).getInt(KEY_INTERVAL, 45)
    fun startMinute(c: Context): Int = prefs(c).getInt(KEY_START, 8 * 60)
    fun endMinute(c: Context): Int = prefs(c).getInt(KEY_END, 22 * 60)
    fun isRunning(c: Context): Boolean = prefs(c).getBoolean(KEY_RUNNING, false)
    fun nextTrigger(c: Context): Long = prefs(c).getLong(KEY_NEXT, 0L)

    fun start(c: Context, interval: Int, startMin: Int, endMin: Int) {
        prefs(c).edit()
            .putInt(KEY_INTERVAL, interval)
            .putInt(KEY_START, startMin)
            .putInt(KEY_END, endMin)
            .putBoolean(KEY_RUNNING, true)
            .apply()
        scheduleFollowing(c)
    }

    fun stop(c: Context) {
        prefs(c).edit().putBoolean(KEY_RUNNING, false).putLong(KEY_NEXT, 0L).apply()
        c.getSystemService(AlarmManager::class.java).cancel(pendingIntent(c))
    }

    /**
     * Alarms ring at start + n * interval (n >= 1) as long as that is not after the end
     * of the window. After the last one, the next alarm is on the following day.
     */
    fun computeNext(now: ZonedDateTime, startMin: Int, endMin: Int, interval: Int): ZonedDateTime {
        for (dayOffset in 0L..1L) {
            val midnight = now.toLocalDate().plusDays(dayOffset).atStartOfDay(now.zone)
            val start = midnight.plusMinutes(startMin.toLong())
            val end = midnight.plusMinutes(endMin.toLong())
            var t = start.plusMinutes(interval.toLong())
            while (!t.isAfter(end)) {
                if (t.isAfter(now)) return t
                t = t.plusMinutes(interval.toLong())
            }
        }
        // Window shorter than one interval: fall back to one interval from now
        return now.plusMinutes(interval.toLong())
    }

    fun scheduleFollowing(c: Context) {
        val next = computeNext(
            ZonedDateTime.now(), startMinute(c), endMinute(c), intervalMinutes(c)
        ).toInstant().toEpochMilli()
        prefs(c).edit().putLong(KEY_NEXT, next).apply()
        schedule(c, next)
    }

    private fun schedule(c: Context, triggerAt: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(c)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun pendingIntent(c: Context): PendingIntent {
        val intent = Intent(c, AlarmReceiver::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(
            c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
