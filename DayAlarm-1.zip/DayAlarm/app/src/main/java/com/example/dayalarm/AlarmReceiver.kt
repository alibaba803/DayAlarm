package com.example.dayalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == AlarmScheduler.ACTION_STOP) {
            AlarmScheduler.stop(context)
            NotificationManagerCompat.from(context).cancel(NotificationHelper.NOTIF_ID)
            return
        }
        if (!AlarmScheduler.isRunning(context)) return
        AlarmScheduler.scheduleFollowing(context)
        NotificationHelper.show(context)
    }
}
