# Day Alarm

Pick a window of the day (e.g. 08:00 - 22:00) and an interval (e.g. 45 min).
The app rings at From + 45, From + 90, ... until the end of the window, and the
notification tells you how much of that window has passed in percent.

## Get the APK without Android Studio
1. Create a free GitHub account and a new empty repository.
2. Upload ALL files from this folder (including the hidden .github folder).
3. Open the "Actions" tab > "Build APK" > wait ~5 minutes for the green check.
4. Open the run, download the artifact "DayAlarm-apk", unzip it, and install
   app-debug.apk on your phone (allow "install unknown apps" when asked).

## Or with Android Studio
File > Open > this folder > Run.
