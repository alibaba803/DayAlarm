package com.example.dayalarm

import java.time.Duration
import java.time.ZonedDateTime

object DayProgress {
    /** Share of the current calendar day (00:00 to 24:00) that has passed, 0.0..100.0 */
    fun percent(now: ZonedDateTime = ZonedDateTime.now()): Double {
        val start = now.toLocalDate().atStartOfDay(now.zone)
        val end = start.plusDays(1)
        val elapsed = Duration.between(start, now).toMillis().toDouble()
        val total = Duration.between(start, end).toMillis().toDouble()
        return (elapsed / total * 100.0).coerceIn(0.0, 100.0)
    }
}
