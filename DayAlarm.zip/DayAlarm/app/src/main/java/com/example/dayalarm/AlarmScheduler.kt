package com.example.dayalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmScheduler {
    const val ACTION_TICK = "com.example.dayalarm.TICK"
    const val ACTION_STOP = "com.example.dayalarm.STOP"

    private const val PREFS = "day_alarm_prefs"
    private const val KEY_INTERVAL = "interval_min"
    private const val KEY_RUNNING = "running"
    private const val KEY_NEXT = "next_trigger"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun intervalMinutes(c: Context): Int = prefs(c).getInt(KEY_INTERVAL, 45)
    fun isRunning(c: Context): Boolean = prefs(c).getBoolean(KEY_RUNNING, false)
    fun nextTrigger(c: Context): Long = prefs(c).getLong(KEY_NEXT, 0L)

    fun start(c: Context, minutes: Int) {
        val first = System.currentTimeMillis() + minutes * 60_000L
        prefs(c).edit()
            .putInt(KEY_INTERVAL, minutes)
            .putBoolean(KEY_RUNNING, true)
            .putLong(KEY_NEXT, first)
            .apply()
        schedule(c, first)
    }

    fun stop(c: Context) {
        prefs(c).edit().putBoolean(KEY_RUNNING, false).putLong(KEY_NEXT, 0L).apply()
        c.getSystemService(AlarmManager::class.java).cancel(pendingIntent(c))
    }

    /** Schedules the next alarm on the fixed grid (start + n * interval), so there is no drift. */
    fun scheduleFollowing(c: Context) {
        val interval = intervalMinutes(c) * 60_000L
        val now = System.currentTimeMillis()
        var next = nextTrigger(c)
        if (next <= now) next += ((now - next) / interval + 1) * interval
        prefs(c).edit().putLong(KEY_NEXT, next).apply()
        schedule(c, next)
    }

    private fun schedule(c: Context, triggerAt: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(c)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun pendingIntent(c: Context): PendingIntent {
        val intent = Intent(c, AlarmReceiver::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(
            c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
