# Day Alarm

Set an interval (e.g. 45 min). The app rings every interval and the notification
shows how much of the day (00:00–24:00) has passed in percent.

## Run it
1. Install Android Studio (Koala or newer).
2. File > Open > select this folder, wait for Gradle sync.
3. Plug in your phone (USB debugging on) or start an emulator, press Run.
4. Allow notifications when asked.

Tip: on some phones (Xiaomi, Samsung, ...) disable battery optimisation for the app
so alarms are not delayed.
